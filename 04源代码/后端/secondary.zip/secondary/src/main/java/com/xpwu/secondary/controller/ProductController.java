package com.xpwu.secondary.controller;

import com.github.pagehelper.PageHelper;
import com.xpwu.secondary.aspect.RequestLimit;
import com.xpwu.secondary.service.ProductService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import com.xpwu.secondary.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/8 16:35
 * @description: 商品相关
 * @version: 1.0
 */
@RestController
@Slf4j
public class ProductController extends BaseController {

    @Autowired
    private ProductService productService;

    /**
     * 获取商品列表 -- 不需要登录
     * @param vo
     *          商品名称，商品类别动态查询
     * @return
     */
    @RequestMapping(value = "getProductList", method = RequestMethod.POST)
    public ResponseBO getProductList(@RequestBody ProductSearchVO vo) {
        // 使用PageHelper工具直接开启分页查询
        PageHelper.startPage(vo.getPageNum(), vo.getPageSize());
        // 调用service查询方法 并返回给客户端
        return ResponseBO.successPageInfo(productService.getProductList(vo));

    }

    /**
     * 发布商品
     * @param productImgs
     * @param vo
     * @return
     */
    @RequestMapping(value = "publishProduct")
    public ResponseBO publishProduct(@RequestParam("productImgs") MultipartFile[] productImgs, @Valid PublishProductVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.notNull(productImgs, "请选择图片");
        vo.setToken(token);
        // 调用发布商品业务
        productService.publishProduct(productImgs, vo);
        return ResponseBO.success();
    }

    /**
     * 获取商品列表 -- 登录后查询
     * @param vo
     *          分类查询我发布的、我卖出的、我买到的
     * @return
     */
    @RequestMapping(value = "getMyProductList", method = RequestMethod.POST)
    public ResponseBO getMyProductList(@Valid @RequestBody MyProductSearchVO vo) {
        Assertion.isTrue(vo != null, "参数为空");
        // 校验token是否为空
        String token = checkToken();
        Assertion.isTrue(1 == vo.getType() || 2 == vo.getType() || 3 == vo.getType(), "type类型错误");
        vo.setToken(token);
        // 调用service查询
        return ResponseBO.successPageInfo(productService.getMyProductList(vo));
    }

    /**
     * 获取商品详情
     * @param productId
     * @return
     */
    @RequestMapping(value = "getProductDetail", method = RequestMethod.GET)
    public ResponseBO getProductDetail(Integer productId) {
        // 校验商品编号
        Assertion.isPositive(productId, "商品编号不能为空");
        // 调用业务service
        return ResponseBO.success(productService.getProductDetail(productId));
    }

    /**
     * 修改商品信息
     * @param productImgs
     * @param vo
     * @return
     */
    @RequestMapping(value = "updateProduct", method = RequestMethod.POST)
    public ResponseBO updateProduct(@RequestParam("productImgs") MultipartFile[] productImgs, @Valid UpdateProductVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 调用修改商品service
        productService.updateProduct(productImgs, vo);
        return ResponseBO.success();
    }

    /**
     * 查询各类商品数量
     * @return
     */
    @RequestMapping(value = "getProductNum", method = RequestMethod.GET)
    public ResponseBO getProductNum() {
        // 校验token是否为空
        String token = checkToken();
        return ResponseBO.success(productService.getProductNum(token));
    }

    /**
     * 删除我发布的商品
     * @param vo
     * @return
     */
    @RequestMapping(value = "delProduct", method = RequestMethod.POST)
    public ResponseBO delProduct(@RequestBody DelProductVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getProductId(), "商品编号不能为空");
        Assertion.isPositive(vo.getType(), "type不能为空");
        // 校验类型是否有效
        Assertion.isTrue(1 == vo.getType() || 2 == vo.getType() || 3 == vo.getType(), "type参数异常");
        vo.setToken(token);
        // 调用删除逻辑
        productService.delProduct(vo);
        return ResponseBO.success();
    }

    /**
     * 获取首页轮播图列表
     * @return
     */
    @RequestLimit(time = 10, count = 3)
    @RequestMapping(value = "getBannerList", method = RequestMethod.GET)
    public ResponseBO getBannerList() {
        return ResponseBO.success(productService.getBannerList());
    }

}
