package com.xpwu.secondary.service;

import com.xpwu.secondary.vo.CommentReplyVO;
import com.xpwu.secondary.entity.CommentReply;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/17 13:28
 * @description: 评论/回复接口
 * @version: 1.0
 */
public interface CommentRelyService extends BaseService<CommentReply, Integer> {

    /**
     * 评论/回复
     * @param vo
     */
    void commentOrReply(CommentReplyVO vo);

}
