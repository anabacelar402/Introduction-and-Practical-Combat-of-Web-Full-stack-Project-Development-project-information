package com.xpwu.secondary.controller;

import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.vo.ChatDetailVO;
import com.xpwu.secondary.vo.InitChatVO;
import com.xpwu.secondary.service.ChatService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/20 20:53
 * @description:
 * @version: 1.0
 */
@RestController
@Slf4j
public class ChatController extends BaseController {

    @Autowired
    private ChatService chatService;

    /**
     * 查询聊天框列表
     * @param vo
     * @return
     */
    @RequestMapping(value = "getChatList", method = RequestMethod.POST)
    public ResponseBO getChatList(BaseVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 调用service服务
        return ResponseBO.successPageInfo(chatService.getChatList(vo));
    }


    /**
     * 查询聊天详情
     * @param vo
     * @return
     */
    @RequestMapping(value = "getChatDetailList", method = RequestMethod.POST)
    public ResponseBO getChatDetailList(@RequestBody ChatDetailVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 校验聊天主表id是够为空
        Assertion.notEmpty(vo.getChatId(), "chatId不能为空");
        // 调用service查询
        return ResponseBO.successPageInfo(chatService.getChatDetailList(vo));
    }

    /**
     * 初始化聊天
     * @param vo
     * @return
     */
    @RequestMapping(value = "initChat", method = RequestMethod.POST)
    public ResponseBO initChat(@RequestBody InitChatVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 校验发送对象用户编号是否为空
        Assertion.notEmpty(vo.getToUserId(), "toUserId不能为空");
        // 校验商品编号是否为空
        Assertion.isPositive(vo.getProductId(), "商品编号不能为空");
        // 调用service服务得到聊天主表编号
        String chatId = chatService.init(vo);
        Map<String, String> map = new HashMap<>(16);
        map.put("chatId", chatId);
        return ResponseBO.success(map);
    }

}
