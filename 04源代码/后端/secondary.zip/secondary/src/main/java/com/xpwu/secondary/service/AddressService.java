package com.xpwu.secondary.service;

import com.xpwu.secondary.vo.AddressVO;
import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.entity.Address;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/10/15 19:47
 * @description:
 * @version: 1.0
 */
public interface AddressService extends BaseService<Address, Integer> {
    /**
     * 获取地址列表
     * @param vo
     * @return
     */
    List<Address> getAddressList(BaseVO vo);

    /**
     * 保存地址
     * @param vo
     */
    void saveAddress(AddressVO vo);

    /**
     * 修改收货地址
     * @param vo
     */
    void updateAddress(AddressVO vo);

    /**
     * 删除收货地址
     * @param vo
     */
    void delAddress(AddressVO vo);
}
