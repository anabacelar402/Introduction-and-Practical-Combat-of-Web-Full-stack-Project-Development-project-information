package com.xpwu.secondary.aspect;

import com.xpwu.secondary.constants.RedisConstants;
import com.xpwu.secondary.enums.CodeEnum;
import com.xpwu.secondary.exception.BusinessException;
import com.xpwu.secondary.utils.IpUtils;
import com.xpwu.secondary.utils.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/11/25 19:50
 * @description: 请求评率控制
 * @version: 1.0
 */
@Aspect
@Component
@Slf4j
@Order(1)
public class RequestLimitAspect {

    /**
     * 定义拦截规则：拦截com.xpwu.secondary.controller包下面的所有类中，有@RequestLimit Annotation注解的方法
     * 。
     */
    @Around("execution(* com.xpwu.secondary.controller.*.*(..))"
            + "&& @annotation(com.xpwu.secondary.aspect.RequestLimit)")
    public Object method(ProceedingJoinPoint pjp) throws Throwable {

        MethodSignature signature = (MethodSignature) pjp.getSignature();
        // 获取被拦截的方法
        Method method = signature.getMethod();
        RequestLimit limt = method.getAnnotation(RequestLimit.class);
        // No request for limt,continue processing request
        if (limt == null) {
            return pjp.proceed();
        }

        HttpServletRequest request = this.getRequest();

        int time = limt.time();
        int count = limt.count();

        String ip = IpUtils.getIp(request);
        String url = request.getRequestURI();

        // 组装key
        String key = requestLimitKey(url, ip);
        long nowCount = RedisUtils.incr(key, time);
        if (nowCount > count) {
            log.info("用户IP[" + ip + "]访问地址[" + url + "]访问次数["
                    + nowCount + "]超过了限定的次数[" + count + "]");
            throw new BusinessException(CodeEnum.REQUEST_TRANSFINITE);
        }

        long start = System.currentTimeMillis();
        log.info("RequestLimtAspect 耗时:" + (System.currentTimeMillis() - start));
        return pjp.proceed();
    }

    /**
     * requestLimitKey: url_ip
     *
     * @param url
     * @param ip
     * @return
     */
    private static String requestLimitKey(String url, String ip) {
        return String.format(RedisConstants.REQUEST_LIMIT, url + "_" + ip);
    }

    private HttpServletRequest getRequest() {
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        return sra.getRequest();
    }

}
