package com.xpwu.secondary.service.impl;

import com.xpwu.secondary.vo.PraiseVO;
import com.xpwu.secondary.entity.Praise;
import com.xpwu.secondary.entity.Product;
import com.xpwu.secondary.entity.User;
import com.xpwu.secondary.mapper.PraiseMapper;
import com.xpwu.secondary.mapper.ProductMapper;
import com.xpwu.secondary.service.PraiseService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.Detect;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/15 15:58
 * @description: 点赞相关服务
 * @version: 1.0
 */
@Service
@Slf4j
public class PraiseServiceImpl extends BaseServiceImpl<Praise, Integer> implements PraiseService {

    @Autowired
    private PraiseMapper praiseMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private ProductMapper productMapper;

    /**
     * 点赞/取消赞
     * @param vo
     */
    @Override
    public void praiseOrUnPraise(PraiseVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        // 查询商品是否存在
        Product product = productMapper.selectByPrimaryKey(vo.getProductId());
        Assertion.notNull(product, "商品不存在");
        // 查询是否存在点赞记录
        Example example = new Example(Praise.class);
        example.createCriteria()
                .andEqualTo("userId", user.getUserId())
                .andEqualTo("productId", vo.getProductId());
        List<Praise> list = praiseMapper.selectByExample(example);
        Date date = new Date();
        if (Detect.notEmpty(list)) {
            Praise praise = Detect.firstOne(list);
            // 已存在点赞记录
            if (null != praise) {
                // 重复点赞或重复取消赞
                Assertion.notEquals(praise.getStatus(), vo.getStatus(), "请勿重复操作");
                BeanUtils.copyProperties(vo, praise);
                praise.setPraiseTime(date);
                praise.setUserAvatar(user.getUserAvatar());
                praise.setUserName(user.getUserName());
                praiseMapper.updateByPrimaryKeySelective(praise);
                return;
            }
        }
        // 不存在点赞记录 但是转入的值为取消赞 参数异常
        Assertion.notEquals(vo.getStatus(), 2, "点赞状态异常");
        // 不存在点赞记录 新增
        Praise praise = new Praise();
        praise.setProductId(vo.getProductId());
        praise.setUserId(user.getUserId());
        praise.setPraiseTime(date);
        praise.setUserAvatar(user.getUserAvatar());
        praise.setUserName(user.getUserName());
        praiseMapper.insertSelective(praise);
    }

    /**
     * 获取点赞列表
     * @param vo
     * @return
     */
    @Override
    public Map<String, Object> getPraiseList(PraiseVO vo) {
        // 根据商品编号查询出有效点赞数据 并按点赞时间升序排列
        Example example = new Example(Praise.class);
        example.createCriteria().andEqualTo("productId", vo.getProductId())
                .andEqualTo("status", 1);
        example.orderBy("praiseTime");
        Map<String, Object> map = new HashMap<>(16);
        map.put("list", praiseMapper.selectByExample(example));
        // 返回值praiseStatus字段为 当前商品是否被当前用户点赞，客户端用于判断页面爱心是否点亮
        // 若token未传，说明未登录，默认未点赞
        if (!Detect.notEmpty(vo.getToken())) {
            map.put("praiseStatus", 2);
            return map;
        }
        // token不为空（已登录） 校验有效性
        User user = userService.checkToken(vo.getToken());
        example.clear();
        // 查询当前登录用户是否对该商品有点赞记录
        example.createCriteria().andEqualTo("productId", vo.getProductId())
                .andEqualTo("userId", user.getUserId());
        List<Praise> list = praiseMapper.selectByExample(example);
        // 无点赞记录， 点赞状态为未点赞
        if (!Detect.notEmpty(list)) {
            map.put("praiseStatus", 2);
            return map;
        }
        Praise praise = Detect.firstOne(list);
        if (null == praise) {
            map.put("praiseStatus", 2);
            return map;
        }
        // 存在点赞记录，将数据库点赞状态赋值给praiseStatus 并返回
        map.put("praiseStatus", praise.getStatus());
        return map;
    }
}
