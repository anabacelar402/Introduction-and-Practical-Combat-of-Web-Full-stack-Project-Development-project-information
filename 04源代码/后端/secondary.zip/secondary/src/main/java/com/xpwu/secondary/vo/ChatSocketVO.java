package com.xpwu.secondary.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/18 23:49
 * @description: 发送聊天入参
 * @version: 1.0
 */
@Setter
@Getter
@ToString(callSuper = true)
public class ChatSocketVO extends BaseVO {

    private static final long serialVersionUID = 5720259669569605483L;

    /**
     * 发送对象用户编号
     */
    private String toUserId;

    /**
     * 发送对象用户昵称
     */
    private String toUserName;

    /**
     * 发送对象用户头像
     */
    private String toUserAvatar;

    /**
     * 发送内容
     */
    private String content;

    /**
     * 聊天编号
     */
    private String chatId;

}
