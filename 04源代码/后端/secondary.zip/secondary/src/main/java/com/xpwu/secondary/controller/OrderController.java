package com.xpwu.secondary.controller;

import com.xpwu.secondary.vo.CommonOrderVO;
import com.xpwu.secondary.vo.OrderVO;
import com.xpwu.secondary.enums.RabbitMqEnum;
import com.xpwu.secondary.rabbitmq.producer.DirectMqSender;
import com.xpwu.secondary.service.OrderService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/15 15:33
 * @description: 订单相关请求
 * @version: 1.0
 */
@RestController
@Slf4j
public class OrderController extends BaseController {

    @Autowired
    private OrderService orderService;

    /**
     * 下单--购买商品
     * @param vo
     * @return
     */
    @RequestMapping(value = "placeOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO placeOrder(@RequestBody OrderVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getProductId(), "商品编号不能为空");
        Assertion.isPositive(vo.getAddressId(), "收货信息不能为空");
        vo.setToken(token);
        return ResponseBO.success(orderService.placeOrder(vo));
    }

    /**
     * 订单详情
     * @param vo
     * @return
     */
    @RequestMapping(value = "getOrderDetails", method = RequestMethod.GET)
    public ResponseBO getOrderDetails(CommonOrderVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getOrderId(), "订单编号不能为空");
        vo.setToken(token);
        return ResponseBO.success(orderService.getOrderDetail(vo));
    }

    /**
     * 取消订单
     * @param vo
     * @return
     */
    @RequestMapping(value = "cancelOrder", method = RequestMethod.POST)
    public ResponseBO cancelOrder(@RequestBody CommonOrderVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getOrderId(), "订单编号不能为空");
        vo.setToken(token);
        orderService.cancelOrder(vo);
        return ResponseBO.success();
    }


    @Autowired
    private DirectMqSender directMqSender;

    /**
     * 测试rabbitmq
     */
    @RequestMapping(value = "testorder", method = RequestMethod.GET)
    public void test() {
        directMqSender.sendTtlMessage(RabbitMqEnum.RoutingEnum.SECONDARY_ORDER_DEAD_LETTER_ROUTING, "123");
    }

}
