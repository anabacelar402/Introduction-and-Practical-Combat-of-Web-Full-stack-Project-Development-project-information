package com.xpwu.secondary.service.impl;

import com.github.pagehelper.PageHelper;
import com.xpwu.secondary.vo.AddressVO;
import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.entity.Address;
import com.xpwu.secondary.entity.User;
import com.xpwu.secondary.mapper.AddressMapper;
import com.xpwu.secondary.service.AddressService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.Detect;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/10/15 19:48
 * @description:
 * @version: 1.0
 */
@Service
@Slf4j
public class AddressServiceImpl extends BaseServiceImpl<Address, Integer> implements AddressService {

    @Autowired
    private UserService userService;

    @Autowired
    private AddressMapper addressMapper;

    /**
     * 收货地址列表
     * @param vo
     * @return
     */
    @Override
    public List<Address> getAddressList(BaseVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        Example example = new Example(Address.class);
        // 根据用户查询有效数据
        example.createCriteria().andEqualTo("userId", user.getUserId()).andEqualTo("status", 1);
        // 按照默认地址升序（默认地址优先排列）、新增时间降序排列
        example.setOrderByClause("is_default_address asc, create_time desc");
        // 开启分页
        PageHelper.startPage(vo.getPageNum(), vo.getPageSize());
        return addressMapper.selectByExample(example);
    }

    /**
     * 新增收货地址
     * @param vo
     */
    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public void saveAddress(AddressVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        Address address = new Address();
        Date date = new Date();
        BeanUtils.copyProperties(vo, address);
        address.setCreateTime(date);
        address.setUpdateTime(date);
        address.setUserId(user.getUserId());
        if (1 == vo.getIsDefaultAddress()) {
            // 如果客户端传入为默认地址 将用户当前默认地址修改为非默认
            Example example = new Example(Address.class);
            example.createCriteria().andEqualTo("isDefaultAddress", 1).andEqualTo("userId", user.getUserId());
            Address update = new Address();
            update.setUpdateTime(date);
            update.setIsDefaultAddress(2);
            addressMapper.updateByExampleSelective(update, example);
        }
        // 新增地址
        addressMapper.insertSelective(address);
    }

    /**
     * 修改收货地址
     * @param vo
     */
    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public void updateAddress(AddressVO vo) {
        // 校验token是否有效
        userService.checkToken(vo.getToken());
        Address address = addressMapper.selectByPrimaryKey(vo.getId());
        Assertion.notNull(address, "收货地址不存在");
        Assertion.isTrue(1 == address.getStatus(), "收货地址已被删除");
        Address update = new Address();
        Date date = new Date();
        // 将请求报文中传入的需要修改的字段copy到update对象中
        BeanUtils.copyProperties(vo, update);
        update.setUpdateTime(date);
        if (Detect.isPositive(vo.getIsDefaultAddress()) && 1 == vo.getIsDefaultAddress()) {
            // 如果客户端传入为默认地址 将用户当前默认地址修改为非默认
            Example example = new Example(Address.class);
            example.createCriteria().andEqualTo("isDefaultAddress", 1).andNotEqualTo("id", vo.getId());
            Address entity = new Address();
            entity.setUpdateTime(date);
            entity.setIsDefaultAddress(2);
            addressMapper.updateByExampleSelective(entity, example);
        }
        addressMapper.updateByPrimaryKeySelective(update);
    }

    /**
     * 删除收货地址
     * @param vo
     */
    @Override
    public void delAddress(AddressVO vo) {
        // 校验token是否有效
        userService.checkToken(vo.getToken());
        Address address = addressMapper.selectByPrimaryKey(vo.getId());
        Assertion.notNull(address, "收货地址不存在");
        Assertion.isTrue(1 == address.getStatus(), "收货地址已被删除，请勿重复操作");
        Address update = new Address();
        // 执行逻辑删除
        update.setStatus(2);
        update.setUpdateTime(new Date());
        update.setId(vo.getId());
        addressMapper.updateByPrimaryKeySelective(update);
    }
}
