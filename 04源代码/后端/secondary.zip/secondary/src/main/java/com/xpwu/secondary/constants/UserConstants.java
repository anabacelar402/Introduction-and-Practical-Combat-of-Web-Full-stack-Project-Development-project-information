package com.xpwu.secondary.constants;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/17 14:42
 * @description:
 * @version: 1.0
 */
public class UserConstants {

    /**
     * 用户头像默认地址
     */
    public final static String DEFAULT_USER_AVATAR = "https://secondary-test.oss-cn-shanghai.aliyuncs.com/images/product/20190817/user_avatar.png";
}
