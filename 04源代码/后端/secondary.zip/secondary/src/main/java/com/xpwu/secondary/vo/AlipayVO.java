package com.xpwu.secondary.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/16 20:36
 * @description: 支付宝支付请求报文
 * @version: 1.0
 */
@Setter
@Getter
@ToString(callSuper = true)
public class AlipayVO extends BaseVO {

    private static final long serialVersionUID = 761808750973621005L;
    /**
     * 订单号
     */
    private Integer orderId;

}
