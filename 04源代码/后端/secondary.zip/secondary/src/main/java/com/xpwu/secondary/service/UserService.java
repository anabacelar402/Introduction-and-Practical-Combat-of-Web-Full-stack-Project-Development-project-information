package com.xpwu.secondary.service;

import com.xpwu.secondary.entity.User;
import com.xpwu.secondary.bo.LoginBO;
import com.xpwu.secondary.vo.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/7 14:50
 * @description:
 * @version: 1.0
 */
public interface UserService extends BaseService<User, String> {

    /**
     * 注册业务
     * @param file
     * @param vo
     */
    void register(MultipartFile file, RegisterVO vo);

    /**
     * 登录业务
     * @param vo
     * @return
     */
    LoginBO login(LoginVO vo);

    /**
     * 获取短信验证码
     * @param vo
     */
    void getVerifyCode(VerifyCodeVO vo);

    /**
     * 校验token是否有效
     * @param token
     * @return
     */
    User checkToken(String token);

    /**
     * 修改密码
     * @param vo
     */
    void updatePwd(UpdatePwdVO vo);

    /**
     * 找回密码
     * @param vo
     */
    void forgotPwd(ForgotPwdVO vo);

    /**
     * 退出登录
     * @param token
     */
    void logout(String token);

    /**
     * 修改用户信息
     * @param file
     * @param vo
     */
    void updateUserInfo(MultipartFile file, UserInfoVO vo);

    /**
     * 校验原手机号
     * @param vo
     */
    void verifyOldMobile(UpdateMobileVO vo);

    /**
     * 绑定新手机号
     * @param vo
     */
    void bindNewMobile(UpdateMobileVO vo);

}
