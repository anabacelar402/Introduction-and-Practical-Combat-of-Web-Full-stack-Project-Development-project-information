package com.xpwu.secondary.service.impl;

import com.github.pagehelper.PageHelper;
import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.vo.ChatDetailVO;
import com.xpwu.secondary.vo.ChatSocketVO;
import com.xpwu.secondary.vo.InitChatVO;
import com.xpwu.secondary.entity.*;
import com.xpwu.secondary.mapper.ChatDetailMapper;
import com.xpwu.secondary.mapper.ChatListMapper;
import com.xpwu.secondary.mapper.ChatMapper;
import com.xpwu.secondary.mapper.ProductMapper;
import com.xpwu.secondary.service.ChatService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.socket.ChatSocket;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.Detect;
import com.xpwu.secondary.utils.UUIDUtils;
import com.xpwu.secondary.bo.ChatBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/19 17:52
 * @description: 聊天框相关业务
 * @version: 1.0
 */
@Service
@Slf4j
public class ChatServiceImpl extends BaseServiceImpl<Chat, Integer> implements ChatService {

    @Autowired
    private ChatMapper chatMapper;

    @Autowired
    private ChatListMapper chatListMapper;

    @Autowired
    private ChatDetailMapper chatDetailMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private ChatSocket chatSocket;

    @Autowired
    private ProductMapper productMapper;

    /**
     * 发送聊天消息并入库
     * @param vo
     */
    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public boolean chat(ChatSocketVO vo) {
        // 校验token
        User user = userService.checkToken(vo.getToken());
        // 查询聊天
        Example example = new Example(Chat.class);
        example.createCriteria().andEqualTo("id", vo.getChatId());
        List<Chat> list = chatMapper.selectByExample(example);
        Date date = new Date();
        String chatId;
        // 第一次聊天
        if (!Detect.notEmpty(list)) {
            // 初始化聊天
            chatId = UUIDUtils.getUid();
            initChat(vo, chatId, null, user, date, 1);
        } else {
            // 不是第一次聊天
            Chat chat = Detect.firstOne(list);
            Assertion.notNull(chat, "数据异常，发送失败");
            chatId = chat.getId();
            // 不在线
            if (!chatSocket.online(vo.getToUserId())) {
                // 查询聊天框记录  校验数据是否正常
                Example chatListExample = new Example(ChatList.class);
                chatListExample.createCriteria().andEqualTo("chatId", chatId)
                        .andEqualTo("userId", vo.getToUserId());
                List<ChatList> chatLists = chatListMapper.selectByExample(chatListExample);
                Assertion.notEmpty(chatLists, "数据异常，发送失败");
                ChatList chatList = Detect.firstOne(chatLists);
                Assertion.notNull(chatList, "数据异常，发送失败");
                ChatList update = new ChatList();
                update.setUnread(chatList.getUnread() + 1);
                update.setId(chatList.getId());
                update.setUpdateTime(date);
                // 聊天未读数+1 并修改入库
                chatListMapper.updateByPrimaryKeySelective(update);
            }
            // 将最后一条消息标识去掉
            Example detailExample = new Example(ChatDetail.class);
            detailExample.createCriteria().andEqualTo("chatId", chatId).andEqualTo("isLatest", 1);
            ChatDetail update = new ChatDetail();
            update.setIsLatest(0);
            update.setUpdateTime(date);
            chatDetailMapper.updateByExampleSelective(update, detailExample);
        }
        // 处理聊天详情记录
        ChatDetail chatDetail = new ChatDetail();
        chatDetail.setChatId(chatId);
        chatDetail.setContent(vo.getContent());
        chatDetail.setCreateTime(date);
        chatDetail.setIsLatest(1);
        chatDetail.setUpdateTime(date);
        chatDetail.setUserAvatar(user.getUserAvatar());
        chatDetail.setUserName(user.getUserName());
        chatDetail.setUserId(user.getUserId());
        // 插入聊天记录
        chatDetailMapper.insertSelective(chatDetail);
        return true;
    }

    /**
     * 初始化聊天数据
     *
     * @param vo
     * @param chatId
     * @param productId
     * @param user
     * @param date
     * @param unread
     */
    private void initChat(ChatSocketVO vo, String chatId, Integer productId, User user, Date date, Integer unread) {
        // 聊天主表插入记录
        Chat chat = new Chat();
        chat.setAnotherUserId(vo.getToUserId());
        chat.setUserId(user.getUserId());
        chat.setId(chatId);
        chat.setProductId(productId);
        chatMapper.insertSelective(chat);
        // 聊天列表新增2条记录  1条为A用户看到的记录，另一条为B用户看到的记录
        ChatList chatList = new ChatList();
        chatList.setAnotherUserId(vo.getToUserId());
        chatList.setAnotherUserAvatar(vo.getToUserAvatar());
        chatList.setAnotherUserName(vo.getToUserName());
        chatList.setCreateTime(date);
        chatList.setUpdateTime(date);
        chatList.setStatus(1);
        // 在线
        if (chatSocket.online(user.getUserId())) {
            chatList.setIsOnline(1);
        } else {
            // 不在线
            chatList.setIsOnline(2);
        }
        chatList.setUserAvatar(user.getUserAvatar());
        chatList.setUserId(user.getUserId());
        chatList.setUserName(user.getUserName());
        chatList.setChatId(chatId);
        if (Detect.isPositive(productId)) {
            chatList.setProductId(productId);
        }
        // A用户聊天列表记录
        chatListMapper.insertSelective(chatList);
        ChatList secondChatList = new ChatList();
        secondChatList.setUserId(vo.getToUserId());
        secondChatList.setUserAvatar(vo.getToUserAvatar());
        secondChatList.setUserName(vo.getToUserName());
        secondChatList.setAnotherUserId(user.getUserId());
        secondChatList.setAnotherUserAvatar(user.getUserAvatar());
        secondChatList.setAnotherUserName(user.getUserName());
        // 不在线
        if (!chatSocket.online(vo.getToUserId())) {
            secondChatList.setUnread(unread);
            secondChatList.setIsOnline(2);
        } else {
            // 在线
            secondChatList.setIsOnline(1);
        }
        secondChatList.setChatId(chatId);
        secondChatList.setCreateTime(date);
        secondChatList.setUpdateTime(date);
        secondChatList.setStatus(1);
        if (Detect.isPositive(productId)) {
            secondChatList.setProductId(productId);
        }
        // B用户聊天列表记录
        chatListMapper.insertSelective(secondChatList);
    }

    /**
     * 查询聊天框数据
     *
     * @param vo
     * @return
     */
    @Override
    public List<ChatBO> getChatList(BaseVO vo) {
        // 校验token
        User user = userService.checkToken(vo.getToken());
        // 开启分页查询
        PageHelper.startPage(vo.getPageNum(), vo.getPageSize());
        // 调用mapper层查询数据
        return chatListMapper.selectChatList(user.getUserId());
    }

    /**
     * 查询聊天详情
     *
     * @param vo
     * @return
     */
    @Override
    public List<ChatDetail> getChatDetailList(ChatDetailVO vo) {
        // 校验token
        User user = userService.checkToken(vo.getToken());
        ChatList chatList = new ChatList();
        // 将未读数变为0
        chatList.setUnread(0);
        Example chatListExample = new Example(ChatList.class);
        chatListExample.createCriteria().andEqualTo("chatId", vo.getChatId())
                .andEqualTo("anotherUserId", user.getUserId());
        // 更新未读数量
        chatListMapper.updateByExampleSelective(chatList, chatListExample);
        // 开启分页查询聊天详情数据
        PageHelper.startPage(vo.getPageNum(), vo.getPageSize());
        Example example = new Example(ChatDetail.class);
        example.createCriteria().andEqualTo("chatId", vo.getChatId());
        // 降序排列
        example.setOrderByClause(" create_time desc");
        // 调用通用查询
        return chatDetailMapper.selectByExample(example);
    }

    /**
     * 初始化聊天
     *
     * @param vo
     * @return
     */
    @Override
    public String init(InitChatVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        // 查询商品信息
        Product product = productMapper.selectByPrimaryKey(vo.getProductId());

        Assertion.notNull(product, "商品信息不存在");
        // 查询聊天主表是否有记录
        Example example = new Example(Chat.class);
        example.createCriteria().andEqualTo("userId", user.getUserId())
                .andEqualTo("anotherUserId", vo.getToUserId())
                .andEqualTo("productId", vo.getProductId());
        List<Chat> list = chatMapper.selectByExample(example);
        String chatId = null;
        if (!Detect.notEmpty(list)) {
            // 将用户编号与对方用户编号对调查询（双方点击都有可能产生聊天记录，所以需要对调参数查询） 再次确认是否有聊天记录
            Example example2 = new Example(Chat.class);
            example2.createCriteria().andEqualTo("anotherUserId", user.getUserId())
                    .andEqualTo("userId", vo.getToUserId())
                    .andEqualTo("productId", vo.getProductId());
            list = chatMapper.selectByExample(example2);
            if (!Detect.notEmpty(list)) {
                // 聊天主表无记录 属于第一次点击 初始化聊天
                User toUser = userService.findById(vo.getToUserId());
                Assertion.notNull(toUser, "对方用户不存在");
                chatId = UUIDUtils.getUid();
                vo.setToUserName(toUser.getUserName());
                vo.setToUserAvatar(toUser.getUserAvatar());
                initChat(vo, chatId, vo.getProductId(), user, new Date(), 0);
                // 返回聊天编号给客户端
                return chatId;
            }
        }
        // 已存在聊天记录 直接返回聊天编号
        Chat chat = Detect.firstOne(list);
        if (chat != null) {
            chatId = chat.getId();
        }
        return chatId;
    }
}
