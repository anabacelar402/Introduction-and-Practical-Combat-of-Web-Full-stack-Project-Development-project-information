package com.xpwu.secondary.service.impl;

import com.aliyun.oss.OSSClient;
import com.github.pagehelper.PageHelper;
import com.xpwu.secondary.entity.Order;
import com.xpwu.secondary.entity.Product;
import com.xpwu.secondary.entity.User;
import com.xpwu.secondary.mapper.OrderMapper;
import com.xpwu.secondary.mapper.ProductMapper;
import com.xpwu.secondary.service.ProductService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.DateUtils;
import com.xpwu.secondary.utils.Detect;
import com.xpwu.secondary.utils.OssUtil;
import com.xpwu.secondary.bo.ProductDetailsBO;
import com.xpwu.secondary.bo.ProductNumBO;
import com.xpwu.secondary.bo.ProductBO;
import com.xpwu.secondary.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/8 16:36
 * @description:
 * @version: 1.0
 */
@Service
@Slf4j
public class ProductServiceImpl extends BaseServiceImpl<Product, Integer> implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private OrderMapper orderMapper;

    /**
     * 发布商品
     * @param files
     * @param vo
     */
    @Override
    public void publishProduct(MultipartFile[] files, PublishProductVO vo) {
        User user = userService.checkToken(vo.getToken());
        // oss存储
        OSSClient ossClient = OssUtil.getOssClient();
        String bucketName = OssUtil.getBucketName();
        String diskName = "images/product/" + DateUtils.getTimeString(new Date());
        StringBuilder stringBuilder = null;
        try {
            stringBuilder = OssUtil.batchUploadInputStreamObject2Oss(ossClient, files, bucketName, diskName);
        } catch (Exception e) {
            Assertion.isTrue(true, "上传失败");
        }
        Assertion.notNull(stringBuilder, "文件上传失败");
        String productImgs = stringBuilder.substring(0, stringBuilder.length() - 1);
        Product product = new Product();
        Date date = new Date();
        BeanUtils.copyProperties(vo, product);
        product.setProductImgs(productImgs);
        product.setCreateTime(date);
        product.setUpdateTime(date);
        product.setPublishUserId(user.getUserId());
        productMapper.insertSelective(product);
    }

    /**
     * 查询首页商品列表
     * @param vo
     * @return
     */
    @Override
    public List<ProductBO> getProductList(ProductSearchVO vo) {
        return productMapper.selectProductList(vo);
    }

    /**
     * 获取商品列表 -- 登录后查询
     * @param vo
     *          分类查询我发布的、我卖出的、我买到的
     * @return
     */
    @Override
    public List<ProductBO> getMyProductList(MyProductSearchVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        // 开启分页查询
        PageHelper.startPage(vo.getPageNum(), vo.getPageSize());
        return productMapper.selectMyProductList(vo.getType(), user.getUserId());
    }

    /**
     * 获取商品详情
     * @param productId
     * @return
     */
    @Override
    public ProductDetailsBO getProductDetail(Integer productId) {
        return productMapper.selectProductDetail(productId);
    }

    /**
     * 修改商品信息
     * @param files
     * @param vo
     */
    @Override
    public void updateProduct(MultipartFile[] files, UpdateProductVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        // 查询商品是否存在
        Product product = productMapper.selectByPrimaryKey(vo.getProductId());
        Assertion.notNull(product, "商品信息不存在");
        // 确认商品发布人为当前登录人
        Assertion.equals(product.getPublishUserId(), user.getUserId(), "只有商品发布人可以修改");
        String productImgs = null;
        StringBuilder stringBuilder = new StringBuilder();
        // 修改商品图片
        if (Detect.notEmpty(files)) {
            // oss存储
            OSSClient ossClient = OssUtil.getOssClient();
            String bucketName = OssUtil.getBucketName();
            String diskName = "images/product/" + DateUtils.getTimeString(new Date());
            try {
                // 批量上传图片
                stringBuilder = OssUtil.batchUploadInputStreamObject2Oss(ossClient, files, bucketName, diskName);
            } catch (Exception e) {
                Assertion.isTrue(true, "上传失败");
            }
            Assertion.notNull(stringBuilder, "文件上传失败");
        }
        if (Detect.notEmpty(vo.getOldImgs())) {
            for (String url : vo.getOldImgs()) {
                stringBuilder.append(url).append(",");
            }
        }
        if (stringBuilder.length() > 1) {
            productImgs = stringBuilder.substring(0, stringBuilder.length() - 1);
        }
        // 修改用户信息
        Product update = new Product();
        Date date = new Date();
        BeanUtils.copyProperties(vo, update);
        update.setProductImgs(productImgs);
        update.setId(vo.getProductId());
        update.setUpdateTime(date);
        productMapper.updateByPrimaryKeySelective(update);
    }

    /**
     * 查询各类商品数量
     * @param token
     * @return
     */
    @Override
    public Map<String, Object> getProductNum(String token) {
        // 校验token有效性
        User user = userService.checkToken(token);
        ProductNumBO bo = productMapper.selectProductNum(user.getUserId());
        // 我发布的
        Map<String, Object> publish = new HashMap<>(2);
        // 我买到的
        Map<String, Object> purchase = new HashMap<>(2);
        // 我卖出的
        Map<String, Object> sale = new HashMap<>(2);
        // 我发布的数量与金额
        publish.put("num", bo.getPublishNum());
        publish.put("money", bo.getPublishAmount());
        // 我买到的数量与金额
        purchase.put("num", bo.getPurchaseNum());
        purchase.put("money", bo.getPurchaseAmount());
        // 我卖出的
        sale.put("num", bo.getSaleNum());
        sale.put("money", bo.getSaleAmount());
        Map<String, Object> result = new HashMap<>(16);
        result.put("publish", publish);
        result.put("purchase", purchase);
        result.put("sale", sale);
        return result;
    }

    /**
     * 获取首页轮播商品列表
     * @return
     */
    @Override
    public List<ProductBO> getBannerList() {
        // 自定义查询轮播商品信息
        List<ProductBO> list = productMapper.selectBannerList();
        // 通过filter将商品图片取第一个返回
        list.stream().filter(o -> {
            String productImgs = o.getProductImgs();
            String [] imgs = productImgs.split(",");
            o.setProductImgs(imgs[0]);
            return true;
        }).collect(Collectors.toList());
        return list;
    }

    /**
     * 删除商品
     * @param vo
     */
    @Override
    public void delProduct(DelProductVO vo) {
        // 校验token是否有效
        User user = userService.checkToken(vo.getToken());
        // 查询商品信息
        ProductBO product = productMapper.selectProductInfoAndTradeStatus(vo.getProductId());
        Assertion.notNull(product, "商品不存在");
        if (1 == vo.getType()) {
            // 删除我发布的
            Assertion.equals(user.getUserId(), product.getPublishUserId(), "只能删除自己发布的商品");
            Assertion.equals(product.getTradeStatus(), 2, "该商品正在交易中，不能被删除");
            productMapper.deleteByPrimaryKey(vo.getProductId());
        } else {
            // 状态必须为 已交易
            Assertion.equals(product.getTradeStatus(), 3, "商品状态异常");
            Assertion.isPositive(product.getOrderId(), "商品状态异常");
            Order order = new Order();
            if (2 == vo.getType()) {
                // 删除我卖出的
                order.setSellingStatus(2);
            } else {
                // 删除我买到的
                order.setBuyingStatus(2);
            }
            order.setUpdateTime(new Date());
            order.setOrderId(product.getOrderId());
            orderMapper.updateByPrimaryKeySelective(order);
        }
    }
}
