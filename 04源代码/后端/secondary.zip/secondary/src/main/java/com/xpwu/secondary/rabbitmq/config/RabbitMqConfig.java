package com.xpwu.secondary.rabbitmq.config;

import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.amqp.SimpleRabbitListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * @author caoxue
 * @description rabbitmq配置
 */
@Configuration
public class RabbitMqConfig {

    /**
     * 连接工厂
     * @param host
     * @param port
     * @param username
     * @param password
     * @param virtualHost
     * @return
     */
    @Primary
    @Bean(name = "connectionFactory")
    public ConnectionFactory connectionFactory(@Value("${spring.rabbitmq.host}") String host,
                                               @Value("${spring.rabbitmq.port}") int port,
                                               @Value("${spring.rabbitmq.username}") String username,
                                               @Value("${spring.rabbitmq.password}") String password,
                                               @Value("${spring.rabbitmq.virtualHost}") String virtualHost) {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setHost(host);
        connectionFactory.setPort(port);
        connectionFactory.setUsername(username);
        connectionFactory.setPassword(password);
        connectionFactory.setVirtualHost(virtualHost);
        return connectionFactory;
    }

    @Primary
    @Bean(name = "rabbitTemplate")
    public RabbitTemplate rabbitTemplate(@Qualifier("connectionFactory") ConnectionFactory connectionFactory) {
        return new RabbitTemplate(connectionFactory);
    }

    @Bean(name = "rabbitAdmin")
    RabbitAdmin rabbitAdmin(@Qualifier("connectionFactory") ConnectionFactory connectionFactory) {
        return new RabbitAdmin(connectionFactory);
    }

    /**
     * 使用@RabbitListener 注解监听所需连接工厂 SimpleRabbitListenerContainerFactory
     * @param configurer
     * @param connectionFactory
     * @param maxConcurrentConsumers
     * @param concurrentConsumers
     * @return
     */
    @Bean(name = "commomFactory")
    public SimpleRabbitListenerContainerFactory commonFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer,
                                                              @Qualifier("connectionFactory") ConnectionFactory connectionFactory,
                                                              @Value("${spring.rabbitmq.maxConcurrentConsumers}") int maxConcurrentConsumers,
                                                              @Value("${spring.rabbitmq.concurrentConsumers}") int concurrentConsumers) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setMaxConcurrentConsumers(maxConcurrentConsumers);
        factory.setConcurrentConsumers(concurrentConsumers);
        configurer.configure(factory, connectionFactory);
        return factory;
    }
}
