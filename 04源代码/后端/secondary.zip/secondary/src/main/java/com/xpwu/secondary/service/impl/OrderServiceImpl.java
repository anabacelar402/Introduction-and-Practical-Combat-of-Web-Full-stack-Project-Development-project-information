package com.xpwu.secondary.service.impl;

import com.xpwu.secondary.exception.BusinessException;
import com.xpwu.secondary.vo.CommonOrderVO;
import com.xpwu.secondary.vo.OrderVO;
import com.xpwu.secondary.constants.RedisConstants;
import com.xpwu.secondary.entity.Address;
import com.xpwu.secondary.entity.Order;
import com.xpwu.secondary.entity.User;
import com.xpwu.secondary.enums.RabbitMqEnum;
import com.xpwu.secondary.mapper.AddressMapper;
import com.xpwu.secondary.mapper.OrderMapper;
import com.xpwu.secondary.mapper.ProductMapper;
import com.xpwu.secondary.rabbitmq.producer.DirectMqSender;
import com.xpwu.secondary.service.OrderService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.Detect;
import com.xpwu.secondary.utils.RedisUtils;
import com.xpwu.secondary.bo.OrderBO;
import com.xpwu.secondary.bo.ProductBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/15 15:23
 * @description:
 * @version: 1.0
 */
@Service
@Slf4j
public class OrderServiceImpl extends BaseServiceImpl<Order, Integer> implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private DirectMqSender directMqSender;

    @Autowired
    private AddressMapper addressMapper;

    @Value("${spring.rabbitmq.order.ttl}")
    private int ttl;

    /**
     * 购买商品
     * @param vo
     * @return
     */
    @Override
    public OrderBO placeOrder(OrderVO vo) {
        try {
            // 校验token是否有效
            User user = userService.checkToken(vo.getToken());
            // 校验商品是否存在
            ProductBO productBO = productMapper.selectProductInfoAndTradeStatus(vo.getProductId());
            Assertion.notNull(productBO, "商品信息不存在");
            Assertion.isTrue(2 == productBO.getTradeStatus(), "该商品正在交易中或已卖出");
            Address address = addressMapper.selectByPrimaryKey(vo.getAddressId());
            Assertion.notNull(address, "收货信息不存在");
            Assertion.isTrue(1 == address.getStatus(), "收货信息已被删除");
            // 设置redis锁 防止商品被重复交易
            long productLock = RedisUtils.setNx(String.format(RedisConstants.PRODUCT_ID, vo.getProductId()), 60, "1");
            if (productLock == 0) {
                log.info("商品正在被交易中，{}", vo.getProductId());
                throw new BusinessException(-1, "商品正在交易中");
            }
            Date date = new Date();
            // 生成待支付订单
            Order order = new Order();
            order.setBuyingUserId(user.getUserId());
            order.setCreateTime(date);
            order.setOrderAmount(productBO.getProductPrice());
            order.setProductId(productBO.getId());
            order.setUpdateTime(date);
            String consigneeAddress = address.getProvince() + " " + address.getCity() + address.getDistrict() + address.getStreet()
                    + " " + address.getAddressDetail();
            order.setConsigneeAddress(consigneeAddress);
            order.setConsigneeMobile(address.getConsigneeMobile());
            order.setConsigneeName(address.getConsigneeName());
            orderMapper.insertSelective(order);
            int orderId = order.getOrderId();
            // 发送延时队列 用于24小时订单超时自动取消
            directMqSender.sendTtlMessage(RabbitMqEnum.RoutingEnum.SECONDARY_ORDER_DEAD_LETTER_ROUTING, orderId + "");
            // 订单有效时长写入redis
            String key = String.format(RedisConstants.ORDER_ID, orderId);
            RedisUtils.setEx(key, ttl / 1000, orderId + "");
            // 组装返回信息
            OrderBO bo = new OrderBO();
            bo.setOrderId(orderId);
            bo.setCreateTime(date);
            bo.setOrderAmount(order.getOrderAmount());
            bo.setPayStatus(1);
            bo.setTradeStatus(1);
            bo.setProductDesc(productBO.getProductDesc());
            bo.setProductImgs(productBO.getProductImgs());
            bo.setBuyerUserName(user.getUserName());
            bo.setExpiredTime((long) ttl);
            return bo;
        } catch (Exception e) {
            // 发生异常 删除redis锁
            RedisUtils.del(String.format(RedisConstants.PRODUCT_ID, vo.getProductId()));
            log.error("购买商品发生异常", e);
        }
        return null;

    }

    /**
     * 取消订单
     * @param vo
     */
    @Override
    public void cancelOrder(CommonOrderVO vo) {
        // 校验token
        userService.checkToken(vo.getToken());
        // 校验订单是否存在
        Order order = orderMapper.selectByPrimaryKey(vo.getOrderId());
        Assertion.notNull(order, "订单不存在");
        Assertion.isTrue(1 == order.getTradeStatus(), "订单已取消或已结算，请勿重复操作");
        Assertion.isTrue(1 == order.getPayStatus() || 4 == order.getPayStatus(), "订单正在付款中或已付款，无法取消");
        Order update = new Order();
        update.setOrderId(vo.getOrderId());
        update.setTradeStatus(2);
        update.setUpdateTime(new Date());
        orderMapper.updateByPrimaryKeySelective(update);
    }

    /**
     * 订单详情
     * @param vo
     * @return
     */
    @Override
    public OrderBO getOrderDetail(CommonOrderVO vo) {
        // 校验token
        userService.checkToken(vo.getToken());
        // 查询订单信息
        OrderBO bo = orderMapper.selectOrderDetailByOrderId(vo.getOrderId());
        Assertion.notNull(bo, "订单信息不存在");
        // 从redis中取出订单剩余有效时间
        String key = String.format(RedisConstants.ORDER_ID, vo.getOrderId());
        long expiredTime = RedisUtils.pttl(key);
        log.info("expiredTime:" + expiredTime);
        bo.setExpiredTime(Detect.isPositive(expiredTime) ? expiredTime / 1000 : 0);
        return bo;
    }
}
