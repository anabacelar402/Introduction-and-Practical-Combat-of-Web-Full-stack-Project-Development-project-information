package com.xpwu.secondary.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/15 15:25
 * @description: 下单接口入参
 * @version: 1.0
 */
@Setter
@Getter
@ToString(callSuper = true)
public class OrderVO extends BaseVO {

    private static final long serialVersionUID = 7569023099860452795L;

    /**
     * 商品编号
     */
    private Integer productId;

    /**
     * 收货地址编号
     */
    private Integer addressId;

}
