package com.xpwu.secondary.service;

import com.xpwu.secondary.bo.ChatBO;
import com.xpwu.secondary.entity.Chat;
import com.xpwu.secondary.entity.ChatDetail;
import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.vo.ChatDetailVO;
import com.xpwu.secondary.vo.ChatSocketVO;
import com.xpwu.secondary.vo.InitChatVO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/19 17:51
 * @description: 聊天框相关接口
 * @version: 1.0
 */
public interface ChatService extends BaseService<Chat, Integer> {

    /**
     * 聊天 -- 发送消息
     * @param vo
     */

    boolean chat(ChatSocketVO vo);

    /**
     * 获取聊天框列表
     * @param vo
     * @return
     */
    List<ChatBO> getChatList(BaseVO vo);

    /**
     * 查询聊天详情
     * @param vo
     * @return
     */
    List<ChatDetail> getChatDetailList(ChatDetailVO vo);

    /**
     * 初始化聊天 -- 点击我想要
     * @param vo
     * @return
     */
    String init(InitChatVO vo);

}
