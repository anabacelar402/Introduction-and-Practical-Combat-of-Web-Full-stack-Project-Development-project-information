package com.xpwu.secondary.service;

import com.xpwu.secondary.bo.OrderBO;
import com.xpwu.secondary.entity.Order;
import com.xpwu.secondary.vo.CommonOrderVO;
import com.xpwu.secondary.vo.OrderVO;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/15 15:22
 * @description: 订单相关接口
 * @version: 1.0
 */
public interface OrderService extends BaseService<Order, Integer> {

    /**
     * 下单--购买商品
     * @param vo
     * @return
     */
    OrderBO placeOrder(OrderVO vo);

    /**
     * 取消订单
     * @param vo
     */
    void cancelOrder(CommonOrderVO vo);

    /**
     * 订单详情信息
     * @param vo
     * @return
     */
    OrderBO getOrderDetail(CommonOrderVO vo);
}
