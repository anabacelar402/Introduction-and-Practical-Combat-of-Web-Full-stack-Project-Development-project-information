package com.xpwu.secondary.service;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/19 17:51
 * @description: 聊天详情相关接口
 * @version: 1.0
 */
public interface ChatDetailService {
}
