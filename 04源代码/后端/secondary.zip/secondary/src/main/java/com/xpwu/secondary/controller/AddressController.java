package com.xpwu.secondary.controller;

import com.xpwu.secondary.vo.AddressVO;
import com.xpwu.secondary.vo.BaseVO;
import com.xpwu.secondary.service.AddressService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/10/15 19:50
 * @description: 收货地址相关控制层
 * @version: 1.0
 */
@RestController
@Slf4j
public class AddressController extends BaseController {

    @Autowired
    private AddressService addressService;

    /**
     * 获取地址列表
     * @param vo
     * @return
     */
    @RequestMapping(value = "getAddressList", method = RequestMethod.POST)
    public ResponseBO getAddressList(BaseVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 调用service服务
        return ResponseBO.successPageInfo(addressService.getAddressList(vo));
    }

    /**
     * 新增收货地址
     * @param vo
     * @return
     */
    @RequestMapping(value = "saveAddress", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO saveAddress(@RequestBody @Valid AddressVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        addressService.saveAddress(vo);
        return ResponseBO.success();
    }

    /**
     * 修改收货地址
     * @param vo
     * @return
     */
    @RequestMapping(value = "updateAddress", method = RequestMethod.POST)
    public ResponseBO updateAddress(@RequestBody AddressVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getId(), "地址编号不能为空");
        vo.setToken(token);
        addressService.updateAddress(vo);
        return ResponseBO.success();
    }

    /**
     * 删除收货地址
     * @param vo
     * @return
     */
    @RequestMapping(value = "delAddress", method = RequestMethod.POST)
    public ResponseBO delAddress(@RequestBody AddressVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.isPositive(vo.getId(), "地址编号不能为空");
        vo.setToken(token);
        addressService.delAddress(vo);
        return ResponseBO.success();
    }
}
