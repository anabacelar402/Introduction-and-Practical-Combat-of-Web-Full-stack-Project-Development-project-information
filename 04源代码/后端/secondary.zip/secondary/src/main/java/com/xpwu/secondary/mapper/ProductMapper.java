package com.xpwu.secondary.mapper;

import com.xpwu.secondary.vo.ProductSearchVO;
import com.xpwu.secondary.entity.Product;
import com.xpwu.secondary.bo.ProductDetailsBO;
import com.xpwu.secondary.bo.ProductNumBO;
import com.xpwu.secondary.bo.ProductBO;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ProductMapper extends Mapper<Product> {

    /**
     * 查询商品详情
     * @param productId
     * @return
     */
    ProductDetailsBO selectProductDetail(@Param("productId") Integer productId);

    /**
     * 查询首页商品列表
     * @param vo
     * @return
     */
    List<ProductBO> selectProductList(ProductSearchVO vo);

    /**
     * 个人中心--商品查询
     * @param type
     * @param userId
     * @return
     */
    List<ProductBO> selectMyProductList(@Param("type") Integer type, @Param("userId") String userId);

    /**
     * 个人中心--查询各类商品数量
     * @param userId
     * @return
     */
    ProductNumBO selectProductNum(@Param("userId") String userId);

    /**
     * 查询首页轮播商品信息
     * @return
     */
    List<ProductBO> selectBannerList();

    /**
     * 查询商品信息及交易状态
     * @param productId
     * @return
     */
    ProductBO selectProductInfoAndTradeStatus(Integer productId);
}
