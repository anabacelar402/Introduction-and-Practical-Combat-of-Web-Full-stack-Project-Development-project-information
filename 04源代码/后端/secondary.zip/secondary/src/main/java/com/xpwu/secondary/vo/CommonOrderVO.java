package com.xpwu.secondary.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/10/14 8:46
 * @description: 订单通用入参
 * @version: 1.0
 */
@Setter
@Getter
@ToString(callSuper = true)
public class CommonOrderVO extends BaseVO {

    private static final long serialVersionUID = -9078025283345783996L;
    /**
     * 订单编号
     */
    private Integer orderId;

}
