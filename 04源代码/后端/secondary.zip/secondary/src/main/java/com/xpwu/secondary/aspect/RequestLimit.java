package com.xpwu.secondary.aspect;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
/**
 * 1分钟内超过50次，访问受限
 * @author caoxue
 *
 */
public @interface RequestLimit {

    // 时间 s
    int time() default 60;

    // 请求次数
    int count() default 50;

}
