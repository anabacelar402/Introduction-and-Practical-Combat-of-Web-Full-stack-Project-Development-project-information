package com.xpwu.secondary.controller;

import com.xpwu.secondary.vo.PraiseVO;
import com.xpwu.secondary.service.PraiseService;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/15 16:57
 * @description: 点赞相关
 * @version: 1.0
 */
@RestController
@Slf4j
public class PraiseController extends BaseController {

    @Autowired
    private PraiseService praiseService;

    @Autowired
    private UserService userService;


    /**
     * 点赞/取消点赞
     * @param vo
     * @return
     */
    @RequestMapping(value = "praiseOrUnPraise", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO praiseOrUnPraise(@Valid @RequestBody PraiseVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 点赞状态枚举值只能为1或者2
        Assertion.isTrue(1 == vo.getStatus() || 2 == vo.getStatus(), "点赞状态异常");
        // 调用点赞service
        praiseService.praiseOrUnPraise(vo);
        return ResponseBO.success();
    }

    /**
     * 获取点赞列表
     * @param vo
     * @return
     */
    @RequestMapping(value = "getPraiseList", method = RequestMethod.GET)
    public ResponseBO getPraiseList(PraiseVO vo) {
        // 与点赞接口共用入参实体 此处不通过@Valid注解与@NotNull校验参数 通过断言校验
        Assertion.notNull(vo, "请求参数不能为空");
        Assertion.isPositive(vo.getProductId(), "商品编号不能为空");
        String token = getToken();
        vo.setToken(token);
        // 调用service查询
        return ResponseBO.success(praiseService.getPraiseList(vo));
    }

}
