package com.xpwu.secondary.controller;

import com.xpwu.secondary.aspect.RequestLimit;
import com.xpwu.secondary.constants.VerifyCodeConstants;
import com.xpwu.secondary.service.UserService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.utils.Detect;
import com.xpwu.secondary.bo.ResponseBO;
import com.xpwu.secondary.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/7 14:25
 * @description: 用户相关
 * @version: 1.0
 */
@RestController
@Slf4j
public class UserController extends BaseController {

    @Autowired
    private UserService userService;

    /**
     * 注册接口
     * @param vo
     *          用户信息入参实体
     * @param userAvatar
     *          用户头像
     * @return
     */
    @RequestMapping(value = "register", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO register(@RequestParam("userAvatar") MultipartFile userAvatar, @Valid RegisterVO vo) {
        // 通过断言校验参数
        Assertion.notNull(userAvatar, "请选择图片");
        Assertion.isMobile(vo.getMobile(), "请输入正确的手机号");
        Assertion.isTrue(Detect.equals(vo.getPassword(), vo.getConfirmPwd()), "两次密码输入不一致");
        // 调用业务逻辑层 注册服务
        userService.register(userAvatar, vo);
        return ResponseBO.success();
    }

    /**
     * 登录接口
     * @param vo
     * @return
     */
    @RequestMapping(value = "login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO login(@Valid @RequestBody LoginVO vo) {
        return ResponseBO.success(userService.login(vo));
    }

    /**
     * 获取验证码接口
     * @param vo
     * @return
     */
    @RequestLimit(count = 5, time = 3600)
    @RequestMapping(value = "getVerifyCode", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO getVerifyCode(@Valid @RequestBody VerifyCodeVO vo) {
        Assertion.isMobile(vo.getMobile(), "请输入正确的手机号");
        Assertion.isTrue(VerifyCodeConstants.REGISTER == vo.getType()
                || VerifyCodeConstants.RETRIEVE_PWD == vo.getType()
                || VerifyCodeConstants.OLD_MOBILE == vo.getType()
                || VerifyCodeConstants.NEW_MOBILE == vo.getType(), "短信类型错误");
        if (VerifyCodeConstants.OLD_MOBILE == vo.getType()) {
            // 校验token是否为空
            String token = checkToken();
            vo.setToken(token);
        }
        userService.getVerifyCode(vo);
        return ResponseBO.success();
    }

    /**
     * 修改密码
     * @param vo
     * @return
     */
    @RequestMapping(value = "updatePwd", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO updatePwd(@Valid @RequestBody UpdatePwdVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.equals(vo.getNewPwd(), vo.getConfirmPwd(), "两次密码输入不一致");
        vo.setToken(token);
        userService.updatePwd(vo);
        return ResponseBO.success();
    }

    /**
     * 忘记密码
     * @param vo
     * @return
     */
    @RequestMapping(value = "forgotPwd", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO forgotPwd(@Valid @RequestBody ForgotPwdVO vo) {
        Assertion.equals(vo.getNewPwd(), vo.getConfirmPwd(), "两次密码输入不一致");
        userService.forgotPwd(vo);
        return ResponseBO.success();
    }

    /**
     * 判断登录是否有效
     * @return
     */
    @RequestMapping(value = "checkLoginValid", method = RequestMethod.POST)
    public ResponseBO checkLoginValid() {
        // 校验token是否为空
        String token = checkToken();
        userService.checkToken(token);
        return ResponseBO.success();
    }

    /**
     * 修改用户信息
     * @return
     */
    @RequestMapping(value = "updateUserInfo", method = RequestMethod.POST)
    public ResponseBO updateUserInfo(MultipartFile userAvatar, UserInfoVO vo) {
        // 校验token是否为空
        String token = checkToken();
        boolean flag = !Detect.notEmpty(vo.getUserName()) && userAvatar == null;
        // 昵称与头像不能同时为空
        Assertion.isTrue(!flag, "参数异常");
        vo.setToken(token);
        // 调用service业务修改用户信息
        userService.updateUserInfo(userAvatar, vo);
        return ResponseBO.success();

    }

    /**
     * 退出登录
     * @return
     */
    @RequestMapping(value = "logout", method = RequestMethod.POST)
    public ResponseBO logout() {
        // 校验token是否为空
        String token = checkToken();
        userService.logout(token);
        return ResponseBO.success();
    }

    /**
     * 校验旧手机号
     * @return
     */
    @RequestMapping(value = "verifyOldMobile", method = RequestMethod.POST)
    public ResponseBO verifyOldMobile(@RequestBody UpdateMobileVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.notEmpty(vo.getMobile(), "旧手机号不能为空");
        Assertion.notEmpty(vo.getVerifyCode(), "验证码不能为空");
        vo.setToken(token);
        // 调用service服务
        userService.verifyOldMobile(vo);
        return ResponseBO.success();
    }

    /**
     * 绑定新手机号
     * @return
     */
    @RequestMapping(value = "bindNewMobile", method = RequestMethod.POST)
    public ResponseBO bindNewMobile(@RequestBody UpdateMobileVO vo) {
        // 校验token是否为空
        String token = checkToken();
        Assertion.notEmpty(vo.getMobile(), "新手机号不能为空");
        Assertion.notEmpty(vo.getVerifyCode(), "验证码不能为空");
        vo.setToken(token);
        // 调用service 绑定新手机号
        userService.bindNewMobile(vo);
        return ResponseBO.success();
    }
}
