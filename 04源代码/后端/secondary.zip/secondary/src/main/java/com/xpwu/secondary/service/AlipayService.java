package com.xpwu.secondary.service;

import com.xpwu.secondary.vo.AlipayVO;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/9/16 20:47
 * @description:
 * @version: 1.0
 */
public interface AlipayService {

    /**
     * 支付宝支付接口
     * @param vo
     * @return
     */
    String alipay(AlipayVO vo);

    /**
     * 支付宝回调通知
     * @param request
     * @return
     */
    String alipayNotify(HttpServletRequest request);
}
