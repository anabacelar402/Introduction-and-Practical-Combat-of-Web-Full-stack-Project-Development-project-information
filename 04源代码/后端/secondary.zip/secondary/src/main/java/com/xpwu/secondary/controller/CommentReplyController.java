package com.xpwu.secondary.controller;

import com.xpwu.secondary.vo.CommentReplyVO;
import com.xpwu.secondary.entity.CommentReply;
import com.xpwu.secondary.service.CommentRelyService;
import com.xpwu.secondary.utils.Assertion;
import com.xpwu.secondary.bo.ResponseBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import tk.mybatis.mapper.entity.Example;

import javax.validation.Valid;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: caoxue
 * @date: 2019/8/17 13:46
 * @description: 评论/回复相关
 * @version: 1.0
 */
@RestController
@Slf4j
public class CommentReplyController extends BaseController {

    @Autowired
    private CommentRelyService commentRelyService;

    /**
     * 评论/回复接口
     * @param vo
     * @return
     */
    @RequestMapping(value = "commentOrReply", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseBO commentOrReply(@Valid @RequestBody CommentReplyVO vo) {
        // 校验token是否为空
        String token = checkToken();
        vo.setToken(token);
        // 调用service评论/回复业务
        commentRelyService.commentOrReply(vo);
        return ResponseBO.success();
    }

    /**
     * 获取评论/回复列表
     * @param productId
     * @return
     */
    @RequestMapping(value = "getCommentReplyList", method = RequestMethod.GET)
    public ResponseBO getCommentReplyList(Integer productId) {
        // 校验商品编号
        Assertion.isPositive(productId, "商品编号不能为空");
        // 根据商品编号查询并按时间升序排列
        Example example = new Example(CommentReply.class);
        example.createCriteria().andEqualTo("productId", productId);
        example.orderBy("createTime");
        // 调用通用查询 并将结果集返回给客户端
        return ResponseBO.success(commentRelyService.findList(example));
    }


}
